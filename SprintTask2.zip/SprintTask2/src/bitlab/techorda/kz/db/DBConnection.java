package bitlab.techorda.kz.db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class DBConnection {
    private static Connection connection;

    static {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            connection = DriverManager.getConnection(
                    "jdbc:mysql://localhost:3306/tech_orda_db",
                    "root",
                    "root");
        }catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static List<Item> getItems() {
        List<Item> items = new ArrayList<>();
        try {
            PreparedStatement statement = connection.prepareStatement(
                    "SELECT p.product_id, p.name_id, p.product_description, p.product_price, pn.name FROM products p INNER JOIN product_names pn ON pn.productName_id = p.name_id;"
            );
            ResultSet resultSet = statement.executeQuery();

            while(resultSet.next()) {
                Item item = new Item();
                item.setId(resultSet.getLong("product_id"));
                item.setName(resultSet.getString("name"));
                item.setDescription(resultSet.getString("product_description"));
                item.setPrice(resultSet.getDouble("product_price"));

                items.add(item);
            }

            statement.close();
        }catch (Exception e) {
            e.printStackTrace();
        }

        return items;
    }

    public static User isCorrect(String user_email, String user_password) {
        User user = new User();
        try {
            PreparedStatement statement = connection.prepareStatement(
                    "SELECT * FROM users WHERE email = ? and password = ?;"
            );
            statement.setString(1, user_email);
            statement.setString(2, user_password);
            ResultSet resultSet = statement.executeQuery();
            if(resultSet.next()) {
                user.setEmail(resultSet.getString("email"));
                user.setId(resultSet.getLong("id"));
                user.setPassword(resultSet.getString("password"));
                user.setFullName(resultSet.getString("full_name"));
            }else {
                user.setId(null);
            }
        }catch (Exception e) {
            e.printStackTrace();
        }
        return user;
    }
}
