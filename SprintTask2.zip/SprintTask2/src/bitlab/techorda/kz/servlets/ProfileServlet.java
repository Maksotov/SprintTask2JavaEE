package bitlab.techorda.kz.servlets;

import bitlab.techorda.kz.db.DBConnection;
import bitlab.techorda.kz.db.Item;
import bitlab.techorda.kz.db.User;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.util.List;

@WebServlet(value = "/profile")
public class ProfileServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        Long id = Long.parseLong(request.getParameter("id"));
        String full_name = request.getParameter("full_name");
        String email = request.getParameter("email");
        String password = request.getParameter("password");

        User user = new User(id, email, password, full_name);
        List<Item> items = DBConnection.getItems();
        request.setAttribute("items", items);
        request.setAttribute("usergo", user);

        request.getRequestDispatcher("/main.jsp").forward(request, response);
    }
}
