package bitlab.techorda.kz.servlets;

import bitlab.techorda.kz.db.DBConnection;
import bitlab.techorda.kz.db.Item;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.util.List;

@WebServlet(value = "/home.html")
public class HomeServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html");
        List<Item> items = DBConnection.getItems();
        request.setAttribute("items", items);
        request.getRequestDispatcher("/main.jsp").forward(request, response);
    }
}
