package bitlab.techorda.kz.servlets;

import bitlab.techorda.kz.db.DBConnection;
import bitlab.techorda.kz.db.Item;
import bitlab.techorda.kz.db.User;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.util.List;

@WebServlet(value = "/signIn")
public class SignInServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html");
        boolean isIncorrect = false;
        request.setAttribute("isInCorrect", isIncorrect);
        request.getRequestDispatcher("/signIn.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String email = null, password = null;
        email = request.getParameter("email"); email = email.trim();
        password = request.getParameter("password"); password.trim();
        User user = DBConnection.isCorrect(email, password);
        System.out.println("kirdi");
        if(user.getId() != null) {
            request.setAttribute("user", user);
//            List<Item> items = DBConnection.getItems();
//            request.setAttribute("items", items);
            request.getRequestDispatcher("/profile.jsp").forward(request, response);
        }else {
            String s = "yes";
            System.out.println("minda");
            request.setAttribute("isInCorrect", "yes");
            request.getRequestDispatcher("/signIn.jsp").forward(request, response);
        }
    }
}
